# Ocean Fresh - Seafood E-commerce Platform

A modern seafood e-commerce platform built with React, Express, and TypeScript, providing an intuitive shopping experience for seafood enthusiasts.

## Features

- 🐟 Browse seafood products by categories
- 🛒 Shopping cart functionality
- 👤 User authentication (login/register)
- 📦 Order management
- ⭐ Product reviews and ratings
- 🎯 Category-based product filtering
- 💳 Checkout process
- 📱 Responsive design

## Tech Stack

- Frontend: React with TypeScript
- Backend: Express.js
- State Management: TanStack Query
- UI Components: shadcn/ui
- Styling: Tailwind CSS
- Authentication: Passport.js
- Data Storage: In-memory storage (can be extended to use PostgreSQL)

## Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory:
```env
SESSION_SECRET=your_session_secret_here
```

4. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Project Structure

```
├── client/          # Frontend React application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── hooks/      # Custom React hooks
│   │   ├── lib/        # Utility functions
│   │   └── pages/      # Page components
├── server/          # Backend Express application
│   ├── auth.ts      # Authentication setup
│   ├── routes.ts    # API routes
│   └── storage.ts   # Data storage implementation
└── shared/          # Shared types and schemas
    └── schema.ts    # Database schema and types
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request
