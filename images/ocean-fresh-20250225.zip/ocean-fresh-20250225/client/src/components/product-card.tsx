import { Product } from "@shared/schema";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Button } from "./ui/button";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

export default function ProductCard({ product }: { product: Product }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  const addToCartMutation = useMutation({
    mutationFn: async (quantity: number) => {
      await apiRequest("POST", "/api/cart", {
        productId: product.id,
        quantity,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: `${product.name} added to your cart`,
      });
    },
  });

  const handleAddToCart = () => {
    if (!user) {
      setLocation("/auth");
      return;
    }
    addToCartMutation.mutate(1);
  };

  const handleBuyNow = () => {
    if (!user) {
      setLocation("/auth");
      return;
    }
    addToCartMutation.mutate(1);
    setLocation("/cart");
  };

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div 
          className="cursor-pointer"
          onClick={() => setLocation(`/product/${product.id}`)}
        >
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h3 className="font-semibold text-lg">{product.name}</h3>
            <p className="text-sm text-muted-foreground">{product.description}</p>
            <p className="mt-2 font-bold text-primary">${product.price.toFixed(2)}</p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex flex-col gap-2">
        <Button 
          className="w-full" 
          onClick={handleAddToCart}
          disabled={addToCartMutation.isPending}
        >
          {addToCartMutation.isPending && (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          )}
          Add to Cart
        </Button>
        <Button 
          variant="secondary" 
          className="w-full"
          onClick={handleBuyNow}
          disabled={addToCartMutation.isPending}
        >
          Buy Now
        </Button>
      </CardFooter>
    </Card>
  );
}