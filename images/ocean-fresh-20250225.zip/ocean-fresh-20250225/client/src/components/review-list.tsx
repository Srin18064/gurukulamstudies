import { User, Review } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "./ui/card";
import { Star, StarHalf } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ReviewListProps {
  productId: number;
}

export default function ReviewList({ productId }: ReviewListProps) {
  const { data: reviews, isLoading } = useQuery<(Review & { user: User })[]>({
    queryKey: [`/api/reviews/${productId}`],
  });

  if (isLoading) {
    return <div>Loading reviews...</div>;
  }

  if (!reviews?.length) {
    return <div className="text-muted-foreground">No reviews yet.</div>;
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <Card key={review.id}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <span className="font-medium">{review.user.username}</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-sm text-muted-foreground">
                  {formatDistanceToNow(new Date(review.createdAt), { addSuffix: true })}
                </span>
              </div>
              <div className="flex">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>
            </div>
            <p className="text-sm">{review.comment}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
