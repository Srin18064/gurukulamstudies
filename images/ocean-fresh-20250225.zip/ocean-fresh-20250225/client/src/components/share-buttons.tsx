import { FaTwitter, FaFacebook, FaWhatsapp } from "react-icons/fa";
import { Button } from "./ui/button";

interface ShareButtonsProps {
  url: string;
  title: string;
  description: string;
}

export default function ShareButtons({ url, title, description }: ShareButtonsProps) {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);

  const shareLinks = [
    {
      name: "Twitter",
      icon: FaTwitter,
      url: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
    },
    {
      name: "Facebook",
      icon: FaFacebook,
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    },
    {
      name: "WhatsApp",
      icon: FaWhatsapp,
      url: `https://wa.me/?text=${encodedTitle}%20-%20${encodedDescription}%20${encodedUrl}`,
    },
  ];

  return (
    <div className="flex gap-2">
      {shareLinks.map((platform) => (
        <Button
          key={platform.name}
          variant="outline"
          size="icon"
          className="rounded-full hover:bg-primary hover:text-white transition-colors"
          asChild
        >
          <a
            href={platform.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Share on ${platform.name}`}
          >
            <platform.icon className="w-4 h-4" />
          </a>
        </Button>
      ))}
    </div>
  );
}