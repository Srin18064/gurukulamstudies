import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import ProductCard from "@/components/product-card";
import ReviewList from "@/components/review-list";
import ReviewForm from "@/components/review-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ShareButtons from "@/components/share-buttons";

export default function ProductPage() {
  const [, params] = useRoute("/product/:id");
  const { toast } = useToast();
  const { user } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [, setLocation] = useLocation();

  const { data: product, isLoading: isLoadingProduct } = useQuery<Product>({
    queryKey: [`/api/products/${params?.id}`],
  });

  const { data: allProducts, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const relatedProducts = allProducts?.filter(
    (p) => p.category?.toLowerCase() === (product?.category?.toLowerCase() || "") && p.id !== product?.id
  ).slice(0, 3);

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/cart", {
        productId: product?.id,
        quantity,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: `${quantity}kg of ${product?.name} added to your cart`,
      });
    },
  });

  const handleBuyNow = () => {
    addToCartMutation.mutate();
    setLocation("/cart");
  };

  if (isLoadingProduct || isLoadingProducts || !product) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container py-8">
      {/* Product Details Section */}
      <div className="grid md:grid-cols-2 gap-8">
        <div className="relative h-[400px] md:h-[600px] rounded-lg overflow-hidden">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold">{product.name}</h1>
                <p className="text-2xl font-bold text-primary mt-2">
                  ${product.price.toFixed(2)} per kg
                </p>
              </div>
              <ShareButtons
                url={window.location.href}
                title={product.name}
                description={product.description}
              />
            </div>
          </div>

          <div className="prose">
            <p className="text-lg">{product.description}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span className="font-medium">Quantity (kg):</span>
              <Select
                value={quantity.toString()}
                onValueChange={(value) => setQuantity(Number(value))}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[0.5, 1, 1.5, 2, 2.5, 3, 4, 5].map((kg) => (
                    <SelectItem key={kg} value={kg.toString()}>
                      {kg} kg
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Button
                className="w-full"
                size="lg"
                onClick={() => addToCartMutation.mutate()}
                disabled={addToCartMutation.isPending || !user}
              >
                {addToCartMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {user ? "Add to Cart" : "Login to Purchase"}
              </Button>
              <Button
                variant="secondary"
                className="w-full"
                size="lg"
                onClick={handleBuyNow}
                disabled={addToCartMutation.isPending || !user}
              >
                Buy Now
              </Button>
              {!user && (
                <p className="text-sm text-muted-foreground text-center">
                  Please login to add items to your cart
                </p>
              )}
            </div>
          </div>

          <div className="border-t pt-6">
            <h2 className="font-semibold mb-2">Product Details</h2>
            <dl className="space-y-2">
              <div className="flex">
                <dt className="w-24 font-medium">Category:</dt>
                <dd>{product.category}</dd>
              </div>
              <div className="flex">
                <dt className="w-24 font-medium">Stock:</dt>
                <dd>{product.stock} kg available</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <section className="mt-16">
        <h2 className="text-2xl font-bold mb-8">Customer Reviews</h2>
        <div className="space-y-8">
          {user ? (
            <div className="border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Write a Review</h3>
              <ReviewForm productId={product.id} />
            </div>
          ) : (
            <p className="text-muted-foreground">
              Please{" "}
              <a href="/auth" className="text-primary hover:underline">
                login
              </a>{" "}
              to leave a review.
            </p>
          )}
          <ReviewList productId={product.id} />
        </div>
      </section>

      {/* Recipes Section */}
      {product.recipes && product.recipes.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-bold mb-8">Recipe Suggestions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {product.recipes.map((recipe, index) => (
              <div
                key={index}
                className="border rounded-lg p-6 space-y-4 hover:shadow-lg transition-shadow"
              >
                <h3 className="text-xl font-semibold text-primary">
                  {recipe.name}
                </h3>
                <p className="text-muted-foreground">{recipe.description}</p>
                <div>
                  <h4 className="font-medium mb-2">Ingredients:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {recipe.ingredients.map((ingredient, i) => (
                      <li key={i} className="text-sm">{ingredient}</li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <span className="font-medium">Cooking Time:</span>
                  <span className="ml-2">{recipe.cookingTime}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Related Products Section */}
      {relatedProducts && relatedProducts.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-bold mb-8">Related Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}