import { useQuery } from "@tanstack/react-query";
import ProductCard from "@/components/product-card";
import { Product } from "@shared/schema";
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import useEmblaCarousel from 'embla-carousel-react'

// Category data with images
const categories = [
  {
    id: "fish",
    name: "Fish",
    image: "https://images.unsplash.com/photo-1544942579-9671c2de2530",
  },
  {
    id: "prawn",
    name: "Prawn",
    image: "https://images.unsplash.com/photo-1565680018434-b583b38e14b5",
  },
  {
    id: "crab",
    name: "Crab",
    image: "https://images.unsplash.com/photo-1559737558-2f5a35f4523b",
  },
  {
    id: "color-fish",
    name: "Color Fish",
    image: "https://images.unsplash.com/photo-1524704796725-9fc3044a58b2",
  },
  {
    id: "dry-fish",
    name: "Dry Fish",
    image: "https://images.unsplash.com/photo-1585545335512-1e43f40d4385",
  },
];

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: 'start',
    loop: true,
  });

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = selectedCategory
    ? products?.filter((product) => product.category.toLowerCase() === selectedCategory)
    : products;

  const scrollPrev = () => emblaApi?.scrollPrev();
  const scrollNext = () => emblaApi?.scrollNext();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative h-[500px] bg-cover bg-center"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1727892177021-9ff43cd8243b')",
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
        <div className="container relative h-full flex flex-col justify-center text-white">
          <h1 className="text-5xl font-bold mb-4">Ocean Fresh Seafood</h1>
          <p className="text-xl max-w-xl">
            Experience the finest selection of fresh seafood delivered straight from the ocean to your table.
          </p>
        </div>
      </section>

      {/* Categories Section */}
      <section className="container py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Browse by Category</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={scrollPrev}
              className="rounded-full hover:bg-primary hover:text-white transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={scrollNext}
              className="rounded-full hover:bg-primary hover:text-white transition-colors"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="overflow-hidden" ref={emblaRef}>
          <div className="flex gap-4">
            {categories.map((category) => (
              <div key={category.id} className="flex-[0_0_200px]">
                <button
                  className={`w-full flex flex-col items-center gap-4 transition-all hover:scale-105 ${
                    selectedCategory === category.id 
                      ? 'opacity-100' 
                      : 'opacity-80 hover:opacity-100'
                  }`}
                  onClick={() => setSelectedCategory(
                    selectedCategory === category.id ? null : category.id
                  )}
                >
                  <div 
                    className={`w-32 h-32 rounded-full overflow-hidden ring-4 transition-shadow ${
                      selectedCategory === category.id 
                        ? 'ring-primary shadow-lg' 
                        : 'ring-transparent hover:ring-primary/50'
                    }`}
                  >
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="font-medium text-lg">{category.name}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="container py-8" id="products">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">
            {selectedCategory 
              ? `${categories.find(c => c.id === selectedCategory)?.name} Products`
              : "Featured Products"}
          </h2>
          {selectedCategory && (
            <Button
              variant="ghost"
              onClick={() => setSelectedCategory(null)}
            >
              View All Products
            </Button>
          )}
        </div>

        {isLoading ? (
          <div className="flex justify-center">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}