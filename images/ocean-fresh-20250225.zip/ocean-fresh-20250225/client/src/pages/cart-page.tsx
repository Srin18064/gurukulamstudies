import { useQuery, useMutation } from "@tanstack/react-query";
import { CartItem, Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import CartItemCard from "@/components/cart-item";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function CartPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: cartItems, isLoading: isLoadingCart } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"],
  });

  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const checkoutMutation = useMutation({
    mutationFn: async () => {
      if (!cartItems || !products) return;

      const items = cartItems.map((item) => {
        const product = products.find((p) => p.id === item.productId);
        if (!product) throw new Error("Product not found");
        return {
          productId: item.productId,
          quantity: item.quantity,
          price: product.price,
        };
      });

      const total = items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      );

      await apiRequest("POST", "/api/orders", { total, items });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Order placed",
        description: "Thank you for your purchase!",
      });
    },
  });

  if (!user) {
    setLocation("/auth");
    return null;
  }

  if (isLoadingCart || isLoadingProducts) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!cartItems?.length) {
    return (
      <div className="container py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Your Cart is Empty</h1>
        <Button asChild>
          <a href="/#products">Continue Shopping</a>
        </Button>
      </div>
    );
  }

  const total = cartItems.reduce((sum, item) => {
    const product = products?.find((p) => p.id === item.productId);
    return sum + (product?.price || 0) * item.quantity;
  }, 0);

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
          {cartItems.map((item) => {
            const product = products?.find((p) => p.id === item.productId);
            if (!product) return null;
            return <CartItemCard key={item.id} item={item} product={product} />;
          })}
        </div>

        <div className="md:col-span-1">
          <div className="sticky top-20 border rounded-lg p-6 space-y-4">
            <h2 className="text-xl font-semibold">Order Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            <Button
              className="w-full"
              size="lg"
              onClick={() => checkoutMutation.mutate()}
              disabled={checkoutMutation.isPending}
            >
              {checkoutMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
