import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertProductSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

const isAdmin = (req: Express.Request, res: Express.Response, next: Express.NextFunction) => {
  if (!req.user?.isAdmin) {
    return res.status(403).send("Admin access required");
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Admin-only routes
  app.get("/api/admin/orders", isAdmin, async (req, res) => {
    const orders = await storage.getAllOrders();
    res.json(orders);
  });

  app.patch("/api/admin/orders/:id", isAdmin, async (req, res) => {
    const schema = z.object({ status: z.string() });
    const { status } = schema.parse(req.body);
    const order = await storage.updateOrderStatus(Number(req.params.id), status);
    res.json(order);
  });

  // Products
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).send("Product not found");
    res.json(product);
  });

  app.post("/api/products", isAdmin, async (req, res) => {
    const product = insertProductSchema.parse(req.body);
    const created = await storage.createProduct(product);
    res.status(201).json(created);
  });

  app.patch("/api/products/:id", isAdmin, async (req, res) => {
    const product = await storage.updateProduct(Number(req.params.id), req.body);
    res.json(product);
  });

  app.delete("/api/products/:id", isAdmin, async (req, res) => {
    await storage.deleteProduct(Number(req.params.id));
    res.sendStatus(204);
  });

  // Reviews
  app.get("/api/reviews/:productId", async (req, res) => {
    const reviews = await storage.getReviews(Number(req.params.productId));
    res.json(reviews);
  });

  app.post("/api/reviews", async (req, res) => {
    if (!req.user) return res.status(401).send("Authentication required");

    const review = insertReviewSchema.parse({
      ...req.body,
      userId: req.user.id,
    });

    const created = await storage.createReview(review);
    res.status(201).json(created);
  });

  // Cart
  app.get("/api/cart", async (req, res) => {
    if (!req.user) return res.status(401).send("Authentication required");
    const items = await storage.getCartItems(req.user.id);
    res.json(items);
  });

  app.post("/api/cart", async (req, res) => {
    if (!req.user) return res.status(401).send("Authentication required");
    const schema = z.object({
      productId: z.number(),
      quantity: z.number().min(1),
    });
    const { productId, quantity } = schema.parse(req.body);
    const item = await storage.addToCart({
      userId: req.user.id,
      productId,
      quantity,
    });
    res.status(201).json(item);
  });

  app.patch("/api/cart/:id", async (req, res) => {
    if (!req.user) return res.status(401).send("Authentication required");
    const schema = z.object({ quantity: z.number().min(1) });
    const { quantity } = schema.parse(req.body);
    const item = await storage.updateCartItem(Number(req.params.id), quantity);
    res.json(item);
  });

  app.delete("/api/cart/:id", async (req, res) => {
    if (!req.user) return res.status(401).send("Authentication required");
    await storage.deleteCartItem(Number(req.params.id));
    res.sendStatus(204);
  });

  const httpServer = createServer(app);
  return httpServer;
}