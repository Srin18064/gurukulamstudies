import { User, Product, CartItem, Order, OrderItem, Review } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: Omit<User, "id">): Promise<User>;

  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: Omit<Product, "id">): Promise<Product>;
  updateProduct(id: number, product: Partial<Product>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  getCartItems(userId: number): Promise<CartItem[]>;
  addToCart(item: Omit<CartItem, "id">): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem>;
  deleteCartItem(id: number): Promise<void>;

  createOrder(order: Omit<Order, "id">, items: Omit<OrderItem, "id">[]): Promise<Order>;
  getOrders(userId: number): Promise<Order[]>;
  getAllOrders(): Promise<Order[]>;
  updateOrderStatus(id: number, status: string): Promise<Order>;

  getReviews(productId: number): Promise<Review[]>;
  createReview(review: Omit<Review, "id" | "createdAt">): Promise<Review>;

  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private reviews: Map<number, Review>;
  private currentId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.reviews = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Create admin user
    this.createUser({
      username: "admin",
      password: "admin",
      isAdmin: true,
    });

    // Add some sample products with recipes
    const sampleProducts = [
      {
        name: "Fresh Salmon",
        description: "Wild-caught Atlantic salmon, perfect for grilling or sushi",
        price: 24.99,
        imageUrl: "https://images.unsplash.com/photo-1535424921017-85119f91e5a1",
        category: "fish",
        stock: 50,
        recipes: [
          {
            name: "Grilled Lemon Herb Salmon",
            description: "A healthy and delicious way to prepare salmon with fresh herbs and lemon.",
            ingredients: ["Salmon fillet", "Lemon", "Fresh herbs", "Olive oil", "Garlic"],
            cookingTime: "20 minutes"
          },
          {
            name: "Teriyaki Glazed Salmon",
            description: "Sweet and savory Asian-inspired salmon dish.",
            ingredients: ["Salmon fillet", "Teriyaki sauce", "Ginger", "Sesame seeds", "Green onions"],
            cookingTime: "25 minutes"
          }
        ]
      },
      {
        name: "Tiger Prawns",
        description: "Large, succulent tiger prawns ideal for grilling or curries",
        price: 19.99,
        imageUrl: "https://images.unsplash.com/photo-1565680018434-b583b38e14b5",
        category: "prawn",
        stock: 100,
        recipes: [
          {
            name: "Garlic Butter Prawns",
            description: "Classic garlic butter prawns with white wine and parsley.",
            ingredients: ["Tiger prawns", "Butter", "Garlic", "White wine", "Parsley"],
            cookingTime: "15 minutes"
          },
          {
            name: "Prawn Curry",
            description: "Creamy coconut curry with aromatic spices.",
            ingredients: ["Tiger prawns", "Coconut milk", "Curry powder", "Onions", "Tomatoes"],
            cookingTime: "30 minutes"
          }
        ]
      },
      {
        name: "Blue Crab",
        description: "Fresh blue crab, perfect for crab cakes or seafood boils",
        price: 15.99,
        imageUrl: "https://images.unsplash.com/photo-1559737558-2f5a35f4523b",
        category: "crab",
        stock: 75,
        recipes: [
          {
            name: "Classic Crab Cakes",
            description: "Maryland-style crab cakes with minimal filler.",
            ingredients: ["Blue crab meat", "Breadcrumbs", "Mayo", "Dijon mustard", "Old Bay seasoning"],
            cookingTime: "25 minutes"
          },
          {
            name: "Garlic Butter Crab Legs",
            description: "Simple and delicious steamed crab legs.",
            ingredients: ["Crab legs", "Butter", "Garlic", "Lemon", "Parsley"],
            cookingTime: "20 minutes"
          }
        ]
      },
      {
        name: "Clown Fish",
        description: "Vibrant, healthy clown fish for your aquarium",
        price: 29.99,
        imageUrl: "https://images.unsplash.com/photo-1524704796725-9fc3044a58b2",
        category: "color-fish",
        stock: 25,
        recipes: []
      },
      {
        name: "Dried Anchovies",
        description: "Premium dried anchovies, perfect for cooking or snacking",
        price: 9.99,
        imageUrl: "https://images.unsplash.com/photo-1585545335512-1e43f40d4385",
        category: "dry-fish",
        stock: 200,
        recipes: [
          {
            name: "Anchovy Stock Base",
            description: "Traditional Korean anchovy stock for soups.",
            ingredients: ["Dried anchovies", "Kelp", "Water", "Garlic", "Onion"],
            cookingTime: "30 minutes"
          },
          {
            name: "Crispy Anchovy Snack",
            description: "Quick fried anchovies with nuts.",
            ingredients: ["Dried anchovies", "Peanuts", "Sesame seeds", "Honey", "Soy sauce"],
            cookingTime: "10 minutes"
          }
        ]
      },
      {
        name: "Tuna Steak",
        description: "High-quality tuna steak, perfect for searing or grilling",
        price: 34.99,
        imageUrl: "https://images.unsplash.com/photo-1574682668544-74b05b991716",
        category: "fish",
        stock: 30,
        recipes: [
          {
            name: "Seared Sesame Tuna",
            description: "Restaurant-style seared tuna with Asian flavors.",
            ingredients: ["Tuna steak", "Sesame seeds", "Soy sauce", "Wasabi", "Ginger"],
            cookingTime: "10 minutes"
          },
          {
            name: "Grilled Tuna Niçoise",
            description: "Classic French salad with grilled tuna.",
            ingredients: ["Tuna steak", "Green beans", "Potatoes", "Olives", "Eggs"],
            cookingTime: "25 minutes"
          }
        ]
      },
      {
        name: "King Crab Legs",
        description: "Large, succulent king crab legs, perfect for a special occasion",
        price: 49.99,
        imageUrl: "https://images.unsplash.com/photo-1514764743342-20448a250d4f",
        category: "crab",
        stock: 15,
        recipes: [
          {
            name: "Garlic Butter Crab Legs",
            description: "Simple and delicious steamed crab legs.",
            ingredients: ["Crab legs", "Butter", "Garlic", "Lemon", "Parsley"],
            cookingTime: "20 minutes"
          }
        ]
      },
      {
        name: "Shrimp Scampi",
        description: "Delicious shrimp scampi, ready to eat",
        price: 12.99,
        imageUrl: "https://images.unsplash.com/photo-1525469689778-85651449967d",
        category: "prawn",
        stock: 50,
        recipes: []
      },
      {
        name: "Sea Bass",
        description: "Fresh sea bass, perfect for baking or pan-frying",
        price: 29.99,
        imageUrl: "https://images.unsplash.com/photo-1528605590249-d728084f1614",
        category: "fish",
        stock: 40,
        recipes: [
          {
            name: "Baked Sea Bass with Herbs",
            description: "Simple baked sea bass with fresh herbs and lemon.",
            ingredients: ["Sea bass fillet", "Lemon", "Fresh herbs", "Olive oil", "Garlic"],
            cookingTime: "25 minutes"
          }
        ]
      }
    ];

    sampleProducts.forEach(product => this.createProduct(product));
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: Omit<User, "id">): Promise<User> {
    const id = this.currentId++;
    const newUser = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: Omit<Product, "id">): Promise<Product> {
    const id = this.currentId++;
    const newProduct = { ...product, id };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: number, update: Partial<Product>): Promise<Product> {
    const product = this.products.get(id);
    if (!product) throw new Error("Product not found");
    const updatedProduct = { ...product, ...update };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    this.products.delete(id);
  }

  async getCartItems(userId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.userId === userId
    );
  }

  async addToCart(item: Omit<CartItem, "id">): Promise<CartItem> {
    const id = this.currentId++;
    const newItem = { ...item, id };
    this.cartItems.set(id, newItem);
    return newItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem> {
    const item = this.cartItems.get(id);
    if (!item) throw new Error("Cart item not found");
    const updatedItem = { ...item, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteCartItem(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async createOrder(
    order: Omit<Order, "id">,
    items: Omit<OrderItem, "id">[]
  ): Promise<Order> {
    const orderId = this.currentId++;
    const newOrder = { ...order, id: orderId };
    this.orders.set(orderId, newOrder);

    items.forEach((item) => {
      const itemId = this.currentId++;
      this.orderItems.set(itemId, { ...item, id: itemId, orderId });
    });

    return newOrder;
  }

  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error("Order not found");
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async getReviews(productId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.productId === productId
    );
  }

  async createReview(review: Omit<Review, "id" | "createdAt">): Promise<Review> {
    const id = this.currentId++;
    const newReview = {
      ...review,
      id,
      createdAt: new Date(),
    };
    this.reviews.set(id, newReview);
    return newReview;
  }
}

export const storage = new MemStorage();