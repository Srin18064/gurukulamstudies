# Ocean Fresh Admin Panel

This package contains the admin panel functionality for the Ocean Fresh e-commerce platform.

## Features

- Product Management (CRUD operations)
- Order Management
- Stock Level Monitoring
- User Management
- Sales Analytics

## Setup

1. Extract the files to your project directory
2. Install dependencies:
```bash
npm install
```

3. Ensure you have an admin user:
   - Default credentials: 
     - Username: admin
     - Password: admin

4. Start the development server:
```bash
npm run dev
```

## Admin Features

### Product Management
- Add new products
- Edit existing products
- Delete products
- Manage stock levels
- Set product categories

### Order Management
- View all orders
- Update order status
- Track order progress
- Cancel orders

### Stock Alerts
- Automatic low stock notifications
- Stock level monitoring
- Inventory management

## Security

The admin panel is protected by authentication and authorization:
- Only users with admin privileges can access the panel
- All admin routes are protected by middleware
- Session management for security

